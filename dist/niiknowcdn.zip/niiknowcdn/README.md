# c5-cdn
Concrete5.7+ CDN plugin.

# Disclaimer
This is my first Concrete5 plugin.  This create a simple and helpful starter/boilerplate for Concrete5.7+ plugin development.

# MIT